API_KEY = "a74c9f5a1f5de1026caaede59ada1ce0-dff1103eb36ccfeb04e087065322149e"
ACCOUNT_ID = "101-012-17790649-001"
OANDA_URL = 'https://api-fxpractice.oanda.com/v3'

SECURE_HEADER = {
    'Authorization': f'Bearer {API_KEY}'
}